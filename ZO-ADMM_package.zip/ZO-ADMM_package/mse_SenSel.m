function [x_sel, mse ]= mse_SenSel(A_allT, x , ksel)
    
   %%% compute trace of estimation error covariance 
    
    Nsen = size(A_allT,2);  
    A_tmp = 0;
    [~, idx ]= sort(x,'descend');
    x_sel = zeros(Nsen,1); x_sel(idx(1:ksel)) = 1; %%% binary selection variable
    for i = 1:Nsen
        an = squeeze(A_allT(:,i,:));
        A_tmp = A_tmp + x_sel(i)*an*an.';
    end
    mse = trace( inv(A_tmp) );
    
end