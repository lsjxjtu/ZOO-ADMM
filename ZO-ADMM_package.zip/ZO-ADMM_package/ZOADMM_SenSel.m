function [x_ave_track,y_ave_track,eps_track, obj_track] = ZOADMM_SenSel(options)

    %%% data/parameter loading
    A_allT = options.data;
    d = size(A_allT,2); %%% number of optimization variables
    N = size(A_allT,3); %%% number of random samples
    x = options.x0;  
    y = options.y0;  
    lam = options.lam0;
    rho = options.rho;
    A = options.A ;
    B = options.B;
    c = options.c;  %%% equality constraint Ax + By - c = 0
    a = options.a; %%% Gt = aI - \eta_t*rho A'*A
    eta_const = options.eta_const ;
    grad_est_const = options.grad_est_const ;
    L_sub_batch_outter = options.L_sub_batch_outter ;
    L_sub_batch_inner = options.L_sub_batch_inner ;
    IterMax = options.IterMax ;
    eps = options.eps ;
    flag_gradFree = options.grad_free; 
    ksel = options.ksel;
    
    %%%  output variable
    x_track = []; y_track = []; y_prime_track = [];
    x_ave_track = []; y_ave_track = [];  eps_track = []; 
    obj_track = func_global_SenSel(A_allT, x);
    y_prim = y;  %%% modified y variable
    
    for t = 1:IterMax
        eta_t = eta_const/sqrt(t*d);
        
        %%% x - step
        grad = 0;
        if ~flag_gradFree %%% full gradient
            idx_sample = randperm(N,L_sub_batch_outter); 
            A_sel = A_allT(:,:,idx_sample); 
            for i = 1:L_sub_batch_outter
                [f_temp , grad_temp]= func_loc_n_SenSel(A_sel(:,:,i),  x);
                grad = grad + grad_temp/L_sub_batch_outter;
            end
        else
            ut = grad_est_const/(t*d);
            idx_sample = randperm(N,L_sub_batch_outter); 
            A_sel = A_allT(:,:,idx_sample); 
            ztj_sub_batch = [];
            for j = 1:L_sub_batch_inner
                ztj = mvnrnd(zeros(1,d),eye(d)).'; %%% i.i.d standard normal distribution dimen: d
                ztj = ztj/norm(ztj,2)*sqrt(d);
                ztj_sub_batch = [ztj_sub_batch,ztj];
            end
            for i = 1:L_sub_batch_outter
                for j = 1:L_sub_batch_inner
                     ztj = ztj_sub_batch(:,j);
                     [f_temp1 , grad_temp1]= func_loc_n_SenSel(A_sel(:,:,i), x+ut*ztj);
                     [f_temp2 , grad_temp2]= func_loc_n_SenSel(A_sel(:,:,i),  x);
                     grad = grad + (f_temp1 - f_temp2)/ut*ztj*(1/(L_sub_batch_inner*L_sub_batch_outter));
                end
            end
        end
        
        %%%% coefficient matrix for Bregman divergence
        Gt = a*eye(d) - eta_t*rho *A.'*A;
        %%%% solution of x-min step
        x_new = (eta_t/a)*(-grad + rho*(y+(1/rho)*lam) + (1/eta_t)*Gt*x );
        x_new(find(x_new<0)) = 0;
        x_new(find(x_new>1)) = 1;

        %%% y step
        y_new = x_new - (1/rho)*lam + (ksel - ones(1,d)*(x_new - (1/rho)*lam))/d*ones(d,1);

        %%% auxiliary y
        y_prim = inv(B)*(c-A*x_new);
        
        %% dual update
        lam_new = lam - rho*(A*x_new + B*y_new - c);
        
        %% 
        x_track = [x_track,x_new]; y_track = [y_track,y_new]; 
        y_prime_track = [y_prime_track,y_prim]; 
        
        x_ave = mean(x_track,2);  y_ave = mean(y_track,2); 
        
        x_ave_track = [x_ave_track,x_ave];  y_ave_track = [y_ave_track,y_ave];
        
        if t > 1
            eps_track = [eps_track; norm(x_ave_track(:,end)-x_ave_track(:,end-1))];
            obj_temp = func_global_SenSel(A_allT, x_ave);
            obj_track = [obj_track;  obj_temp];
            if mod(t,50) == 0
               disp(sprintf('ADMM for iter = %d with xeps = %4.5f, xyeps = %4.5f, obj = %4.5f',...
                    t, eps_track(end), norm(A*x_ave + B*y_ave - c,2) ,obj_track(end))); 
            end
        end
        
        if t > 50 && norm(eps_track(end)-eps_track(end-1)) < eps && norm(obj_track(end) - obj_track(end-1)) < eps*abs(obj_track(end)) && norm(obj_track(end) - obj_track(end-30)) < eps*abs(obj_track(end))
        else
             x = x_new; y = y_new; lam = lam_new;  
        end
        
    end
    
    
    
    

end