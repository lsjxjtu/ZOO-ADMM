function [x_ave_track,y_ave_track,eps_track, obj_track] = ZOADMM_overlapGroupLasso(options)


    %%% assign parameters from options
    an_matrix = options.data{1};
    cn_vec = options.data{2};
    d = size(an_matrix,1); 
    m = fix(sqrt(d));
    N = size(an_matrix,2);
    x = options.x0;  
    y = options.y0;  
    lam = options.lam0;
    rho = options.rho;
    A = options.A ;
    a = options.a; %%% Gt = aI - \eta_t*rho A'*A
    eta_const = options.eta_const ;
    grad_est_const = options.grad_est_const ;
    L_sub_batch_outter = options.L_sub_batch_outter ;
    L_sub_batch_inner = options.L_sub_batch_inner ;
    IterMax = options.IterMax ;
    eps = options.eps ;
    flag_gradFree = options.grad_free; 
    spase_para = options.sparse_para;
    
    %%% 
    x_track = []; y_track = []; eps_track = []; x_ave_track = []; y_ave_track = [];
    obj_track = func_global_overlapGroupLasso(an_matrix, cn_vec, spase_para, x); %% objective value (cumulative cost)
    y_prim = y; %%% modified primal variable y^\prime from y
    
    for t = 1:IterMax
        
        eta_t = eta_const/sqrt(t*d);  %% learning rate
        
        %%% x - step
        %%% first compute gradient/gradient estimate
        grad = 0;
        if ~flag_gradFree %%% full gradient
            idx_sample = randperm(N,L_sub_batch_outter); %%% randomly pick training samples
            A_sel = an_matrix(:,idx_sample); 
            cn_sel = cn_vec(idx_sample);
            for i = 1:L_sub_batch_outter
                [f_temp , grad_temp]= func_loc_overlapGroupLasso(A_sel(:,i), cn_sel(i), x); %%% online cost function
                grad = grad + grad_temp/L_sub_batch_outter;  %%% gradient averaged over observations
            end
        else %%% zero-order
            ut = grad_est_const/(t*d^1.5); %%%  smooth parameter
            idx_sample = randperm(N,L_sub_batch_outter); 
            A_sel = an_matrix(:,idx_sample); 
            cn_sel = cn_vec(idx_sample); 
            ztj_sub_batch = [];
            for j = 1:L_sub_batch_inner
                ztj = mvnrnd(zeros(1,d),eye(d)).';
                ztj = ztj/norm(ztj,2)*sqrt(d);   %%% random gradient samples i.i.d standard normal distribution
                ztj_sub_batch = [ztj_sub_batch,ztj];
            end
            for i = 1:L_sub_batch_outter
                for j = 1:L_sub_batch_inner
                     ztj = ztj_sub_batch(:,j);
                     [f_temp1 , ~]= func_loc_overlapGroupLasso(A_sel(:,i), cn_sel(i), x+ut*ztj);
                     [f_temp2 , ~]= func_loc_overlapGroupLasso(A_sel(:,i), cn_sel(i), x);
                     grad = grad + (f_temp1 - f_temp2)/ut*ztj*(1/(L_sub_batch_inner*L_sub_batch_outter)); %% hybrid minibatch strategy
                end
            end
        end
        
%         Gt = a*eye(d) - eta_t*rho *A.'*A; %%% Bregman divergence coefficient matrix
%         x_new = eta_t/a*( - grad + A.'*lam + rho*A.'*y + (1/eta_t)*Gt*x );
                
        x_new = eta_t/a*( - grad + A.'*( lam - rho*A*x + rho*y ) ) + x;

        %%% y step
        coeff_y = A*x_new - (1/rho)*lam;
        gam_coeff = spase_para/rho;
        y_new = zeros(2*d,1);
        for i = 1:m %%% m rows
            idx_rowi = i:m:d;
            idx_coli = ( (i-1)*m+1+d ) : (i*m+d);
            coeff_yrowi = coeff_y(idx_rowi);
            coeff_ycoli = coeff_y(idx_coli);
            
            if norm(coeff_yrowi) > gam_coeff
                y_new(idx_rowi) = (1-gam_coeff/norm(coeff_yrowi))*coeff_yrowi;
            else
                y_new(idx_rowi)  = 0;
            end
            if norm(coeff_ycoli) > gam_coeff
                y_new(idx_coli) = (1-gam_coeff/norm(coeff_ycoli))*coeff_ycoli;
            else
                y_new(idx_coli)  = 0;
            end
        end
        y_prim = A*x_new;
        
        %% dual update
        lam_new = lam - rho*(A*x_new - y_new);
        
        %% 
        x_track = [x_track,x_new]; y_track = [y_track,y_prim]; 
        x_ave = mean(x_track,2);  y_ave = mean(y_track,2); %%% running average
        x_ave_track = [x_ave_track,x_ave];  y_ave_track = [y_ave_track,y_ave];
        
        if t > 1
            eps_track = [eps_track; norm(x_ave_track(:,end)-x_ave_track(:,end-1))];
            obj_temp = func_global_overlapGroupLasso(an_matrix, cn_vec, spase_para, x_ave);
            obj_track = [obj_track;  obj_temp];
            if mod(t,100) == 0
                 disp(sprintf('ADMM for iter = %d with xeps = %4.5f, xyeps = %4.5f, obj = %4.5f',...
                    t, eps_track(end), norm(A*x_new - y_new,2) ,obj_track(end))); 
            end
        end
        
        if t > 1 && eps_track(end) < eps
%             break;
        else
             x = x_new; y = y_new; lam = lam_new;  
        end
        
    end
    
    
    
    

end