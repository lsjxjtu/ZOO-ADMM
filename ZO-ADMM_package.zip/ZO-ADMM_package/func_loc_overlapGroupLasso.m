function [f , grad]= func_loc_overlapGroupLasso(an, cn, x)

    f = log(1+exp( -cn*(an.'*x) ));
    grad =  ( exp( -cn*(an.'*x) ) )/( 1+exp( -cn*(an.'*x) ) ) * (-cn) * an;
end