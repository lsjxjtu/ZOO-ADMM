%%%%%%%%%%%% Author: Sijia Liu %%%%%%%%%%%%%%%%
%%%%%%%%%%%% Date: 08/02/2017
%%% Application name: ZO-ADMM for sparse classification via overlapping group Lasso

clc; clear all; close all;

sz_vec = [30]; %%% minibatch size given by sz_vec

%%% load training data
load('dataSample_overlapGroupLasso.mat','an_matrix','cn_vec')
d = size(an_matrix,1); %% problem size, namely, num. of optimization variables
N = size(an_matrix,2); %% num. of training examples

obj_track_M_OADMM = cell(length(sz_vec),1); %%%% objective value trajectory in OADMM
eps_track_M_OADMM = cell(length(sz_vec),1); %%%% Update error trajectory in OADMM
x_sol_M_OADMM = cell(length(sz_vec),1); %%%% Running average solution trajectory in OADMM
etime_M_OADMM  = cell(length(sz_vec),1); %%%% Computation time in OADMM

obj_track_M_ZOADMM = cell(length(sz_vec),1); %%%% objective value trajectory in ZOADMM with minibatch scheme 1 (observation sample based)
eps_track_M_ZOADMM = cell(length(sz_vec),1); %%%% Update error trajectory in ZOADMM with minibatch scheme 1 (observation sample based)
x_sol_M_ZOADMM = cell(length(sz_vec),1); %%% Running average solution trajectory in ZOADMM with minibatch scheme 1 (observation sample based)
etime_M_ZOADMM  = cell(length(sz_vec),1); %%%% Computation time in ZOADMM with minibatch scheme 1 (observation sample based)

%%%% ZO-ADMM with minibatch scheme 2 (gradient sample based)
obj_track_M_ZOADMM2 = cell(length(sz_vec),1);
eps_track_M_ZOADMM2 = cell(length(sz_vec),1);
x_sol_M_ZOADMM2 = cell(length(sz_vec),1);
etime_M_ZOADMM2  =cell(length(sz_vec),1);


%%%% set ZO-ADMM parameters
options.x0 = 1e-2*rand(d,1); %%% initial value for primal variable x
options.lam0 = zeros(2*d,1); %%% initial value for dual variable \lambda
options.rho = 1;  %%% parameter of Augmented Lag. 
options.A = [eye(d); eye(d)]; 
options.B = -eye(2*d);  
options.c = zeros(2*d,1); %%% coeffieicents in equality constraint of ADMM, Ax + By = c.
options.a = 10; %%% Gt = aI - \eta_t*rho A'*A, linearized ADMM technique
options.y0 = inv(-options.B)*( options.A * options.x0 - options.c ); %%% initial value for primal variable y
options.eta_const = 1; %%% parameter in learning rate \eta_t
options.grad_est_const = 1; %%% parameter in smoothing parameter \beta_t  
options.IterMax = 1e4; %%% max. number of iterations
options.data{1} = an_matrix;
options.data{2} = cn_vec; %%  training data
options.sparse_para = 0.025; %%% sparsity promoting parameter
%%% adjust parameter in Gt such that Gt >= I
 while 1
     if min(  eig( options.a*eye(d) - (options.eta_const)*options.rho *options.A.'*options.A ) ) < 1
        options.a = options.a*1.1;
     else
         break;
     end
 end

for  isz = 1:length(sz_vec)
    
    %%% Method I: O-ADMM
    options.grad_free = 0; %%% 0: full gradient; 1: gradient estimate (zeroth-order)
    options.eps = 1e-6; 
    options.L_sub_batch_outter = sz_vec(isz);  %%% observation sample based minibatch size
    options.L_sub_batch_inner = 1; %%% gradient sample based minibatch size

    tStart0 = tic;
    [x_ave_track0,y_ave_track0,eps_track0, obj_track0] = ZOADMM_overlapGroupLasso(options);
    tElapsed0 = toc(tStart0); 
        
    obj_track_M_OADMM{isz,1} = obj_track0;
    eps_track_M_OADMM{isz,1} = eps_track0;
    x_sol_M_OADMM{isz,1} = x_ave_track0(:,end);
    etime_M_OADMM{isz,1} = tElapsed0;
    
    disp(sprintf('OADMM with d = %d, minbatch = %d, obj = %4.3f, eps = %3.4f, time = %3.4f',...
              d, sz_vec(isz), obj_track0(end), eps_track0(end), tElapsed0   )); 
          
    %%% Method II-1: ZO-ADMM,  observation sample based minibatch   
    options.grad_free = 1; options.eps = 1e-6; 
    options.L_sub_batch_outter = sz_vec(isz);  options.L_sub_batch_inner = 1;
    tStart = tic;
    [x_ave_track,y_ave_track,eps_track, obj_track] = ZOADMM_overlapGroupLasso(options);
    tElapsed = toc(tStart); 
         
    obj_track_M_ZOADMM{isz,1} = obj_track;
    eps_track_M_ZOADMM{isz,1} = eps_track;
    x_sol_M_ZOADMM{isz,1} = x_ave_track(:,end);
    etime_M_ZOADMM{isz,1} = tElapsed;
           
    disp(sprintf('ZOADMM with d = %d, minbatch_out = %d, obj = %4.3f, eps = %3.4f, time = %3.4f',...
              d, sz_vec(isz), obj_track(end), eps_track(end), tElapsed   )); 
          
          
    %%% Method II-2: ZO-ADMM,  gradient sample based minibatch        

    options.grad_free = 1; options.eps = 1e-6; 
    options.L_sub_batch_outter = 1;  options.L_sub_batch_inner = sz_vec(isz);
    tStart2 = tic;
    [x_ave_track2,y_ave_track2,eps_track2, obj_track2] = ZOADMM_overlapGroupLasso(options);
    tElapsed2 = toc(tStart2); 
    obj_track_M_ZOADMM2{isz,1} = obj_track2;
    eps_track_M_ZOADMM2{isz,1} = eps_track2;
    x_sol_M_ZOADMM2{isz,1} = x_ave_track2(:,end);
    etime_M_ZOADMM2{isz,1} = tElapsed2;
         
    disp(sprintf('ZOADMM with d = %d, minbatch_in = %d, obj = %4.3f, eps = %3.4f, time = %3.4f',...
              d, sz_vec(isz), obj_track2(end), eps_track2(end), tElapsed2   ));       
end
 
 


%%% plot: minibatch = 1; different dimension of problem
marker_sym = {'o', '^', 'd'}; 
col_sym = {'b', 'g', 'r'}; %% ZO ADMM; O-ADMM
lin_sym = {'-', '--',':'};
idx_plot = 1:1:(options.IterMax-1);  
idx_plot2 = 1:2000:(options.IterMax-1);
hcolor = [];


%%% example of plots: impact of minibatch
 
figure;  hcolor = [];

plot(idx_plot,obj_track_M_ZOADMM{1,1}(idx_plot),'LineStyle', lin_sym{1}, 'Color',col_sym{1},'LineWidth',1.5); hold on;
plot(idx_plot2,obj_track_M_ZOADMM{1,1}(idx_plot2),'LineStyle', 'none', 'Marker',marker_sym{1},'MarkerEdgeColor',col_sym{1},'MarkerSize',5); hold on;

plot(idx_plot,obj_track_M_ZOADMM2{1,1}(idx_plot),'LineStyle', lin_sym{3}, 'Color',col_sym{3},'LineWidth',1.5); hold on;
plot(idx_plot2,obj_track_M_ZOADMM2{1,1}(idx_plot2),'LineStyle', 'none', 'Marker',marker_sym{3},'MarkerEdgeColor',col_sym{3},'MarkerSize',5); hold on;

plot(idx_plot,obj_track_M_OADMM{1,1}(idx_plot),'LineStyle', lin_sym{2}, 'Color',col_sym{2},'LineWidth',1.5); hold on;
plot(idx_plot2,obj_track_M_OADMM{1,1}(idx_plot2),'LineStyle', 'none', 'Marker',marker_sym{2},'MarkerEdgeColor',col_sym{2},'MarkerSize',5); hold on;

hcolor(1) = plot(NaN, NaN, 'LineStyle', lin_sym{1}, 'Color',col_sym{1},...
    'Marker',marker_sym{1},'MarkerEdgeColor',col_sym{1},'MarkerSize',5,'LineWidth',1.5);hold on;
hcolor(2) = plot(NaN, NaN, 'LineStyle', lin_sym{3}, 'Color',col_sym{3},...
    'Marker',marker_sym{3},'MarkerEdgeColor',col_sym{3},'MarkerSize',5,'LineWidth',1.5);hold on;
hcolor(3) = plot(NaN, NaN, 'LineStyle', lin_sym{2}, 'Color',col_sym{2},...
    'Marker',marker_sym{2},'MarkerEdgeColor',col_sym{2},'MarkerSize',5,'LineWidth',1.5);hold on;
legend(hcolor,{'ZO-ADMM: minibatch \{w_t\} of sz = 20','ZO-ADMM: minibatch \{z_t\} of sz = 20','O-ADMM: minibatch \{w_t\} of sz = 20'});
xlabel('Iteration');
ylabel('Objective value');

