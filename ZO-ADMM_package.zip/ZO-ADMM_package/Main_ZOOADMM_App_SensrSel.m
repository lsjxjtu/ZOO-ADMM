%%%%%%%%%%%% Author: Sijia Liu %%%%%%%%%%%%%%%%
%%%%%%%%%%%% Date: 08/02/2017
%%% Application name: ZO-ADMM for sensor selection

clc; clear all; close all;

%%% input data: observation gains, location of sensors, and location of
%%% targets/field points to be monitored 
load('dataSample_sensrSel.mat','A_allT','Locs_sensors','Loc_target');
Ntar = size(A_allT,1); %%% num. of field points to be estimated
Nsen = size(A_allT,2); %%% number of sensors, problem size, dimension of optimization variables
Ksel_vec = 5:5:20;  %%% desired selected sensors

mse_track_OADMM = zeros(length(Ksel_vec),1);  %%% MSE based on sensor selection schemes using OADMM
mse_track_ZOADMM = zeros(length(Ksel_vec),1);  %%% MSE based on sensor selection schemes using ZOADMM
xsel_track_OADMM = zeros(Nsen,length(Ksel_vec),1);
xsel_track_ZOADMM = zeros(Nsen,length(Ksel_vec),1);
% eps_track_OADMM = [];  %%% update error trajectory
% eps_track_ZOADMM = [];


%%%% parameter setting in ZOADMM
d = Nsen; %%Optimization varaibles dimension
options.A = eye(d);
options.B = -eye(d);
options.c = zeros(d,1); %%% coefficients of equality constraint Ax + By = c
options.rho = 1;
options.x0 = ones(d,1)*0.5;
options.y0 = inv(-options.B)*( options.A * options.x0 - options.c );
options.lam0 = zeros(d,1);
options.a = 10; %%% Gt = aI - \eta_t*rho A'*A, Bregman divergence coefficient matrix
options.eta_const = 1; %%% related to step size for Bregman divergence, learning rate
options.grad_est_const = 1; %%% related to step size of directional derivative, smoothing parameter
options.IterMax = 2e4; %%% max. iteration
options.data = A_allT;  %%% online data
%%%% ensure Gt >= I    
while 1
        if min(  eig( options.a*eye(d) - (options.eta_const)*options.rho *options.A.'*options.A ) ) < 1
            options.a = options.a*1.1;
        else
            break;
        end
end

for j = 1:length(Ksel_vec) %%% different numbers of selected sensors
        options.ksel  = Ksel_vec(j);
        
        %% Method 1: second order method, primal dual interior point,  CVX solver should be installed first, http://cvxr.com/cvx/
        A_tmp = [];
        for ii = 1:Nsen
            an = squeeze(A_allT(:,ii,:));
            A_tmp = [A_tmp , an*an.'];
        end
        T = size(A_allT,3);        
        cvx_begin   
        variable x_cvx(d);
        minimize -log_det( A_tmp*kron(x_cvx,eye(size(A_allT,1))) ) ;
        subject to
            x_cvx>=0;
            x_cvx<=1;
            sum(x_cvx) == options.ksel;
        cvx_end
        
       [x_sel_cvx, mse_cvx ]= mse_SenSel(A_allT, x_cvx ,  options.ksel ) ;
       xsel_track_cvx(:,j) = x_sel_cvx;
       mse_track_cvx(j) = mse_cvx;
       
        %%% Method 2: online ADMM
        options.grad_free = 0; %%% 0: full gradient
        options.eps = 1e-6;  %%% stopping rule
        options.L_sub_batch_outter = 50;  options.L_sub_batch_inner = 1; %%% sub-batch strategy
        %%% call algorithm
        [x_ave_track_OADMM,y_ave_track_OADMM,eps_track_OADMM_tmp, obj_track_OADMM_tmp] = ZOADMM_SenSel(options);
        
        
        
        eps_track_OADMM(:,j) = eps_track_OADMM_tmp;
        obj_track_OADMM(:,j) = obj_track_OADMM_tmp;
        [x_sel_OADMM, mse_OADMM ]= mse_SenSel(A_allT, x_ave_track_OADMM(:,end) ,  options.ksel ) ;
        mse_track_OADMM(j) = mse_OADMM;
        xsel_track_OADMM(:,j) = x_sel_OADMM;
        
        %%% Method 3: ZO-ADMM
        options.grad_free = 1; options.eps = 1e-6; 
        options.L_sub_batch_outter = 1;  options.L_sub_batch_inner = 50;
        [x_ave_track_ZOADMM,y_ave_track_ZOADMM,eps_track_ZOADMM_tmp, obj_track_ZOADMM_tmp] = ZOADMM_SenSel(options);
        
        eps_track_ZOADMM(:,j) = eps_track_ZOADMM_tmp;
        obj_track_ZOADMM(:,j) = obj_track_ZOADMM_tmp;
        [x_sel_ZOADMM, mse_ZOADMM ]= mse_SenSel(A_allT, x_ave_track_ZOADMM(:,end) ,  options.ksel ) ;
        mse_track_ZOADMM(j) = mse_ZOADMM;
        xsel_track_ZOADMM(:,j) = x_sel_ZOADMM;
       
end

%%% MSE
hfig = figure;
plot(Ksel_vec,mse_track_cvx,'-ro'); hold on;
plot(Ksel_vec,mse_track_OADMM,'-b^'); hold on;
plot(Ksel_vec,mse_track_ZOADMM,'-ks'); 
xlabel('No. of selected sensors')
ylabel('Mean sqaured error');
legend('CVX','O-ADMM','ZO-ADMM')




