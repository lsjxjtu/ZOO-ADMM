function obj= func_global_overlapGroupLasso(an_matrix, cn_vec, alpha, x)
    N = size(an_matrix,2); obj = 0; d = size(an_matrix,1); m = fix(sqrt(d));
    for i = 1:N
        cn = cn_vec(i); an = an_matrix(:,i);
        obj = obj + log(1+exp( -cn*(an.'*x) ))/N;
    end
    X = reshape(x,m,m);
    obj = obj + sum(alpha*sqrt(sum(X.^2,1))) + sum(alpha*sqrt(sum((X.').^2,1))) ;
    
end