function y = func_global_Cox( x, A, delta, R, lam )
    %%% Cox objective function
    N = size(A,2);
    y = 0;
    for i = 1 : N,
            y = y + (-delta(i)*A(:,i)'*x);
            Ri = R{i};
            temp = 0;
            for j = 1:length(Ri)
                jj = Ri(j);
                temp = temp + exp( A(:,jj)'*x );
            end
            y = y + delta(i)*log(temp);
    end
    y = y + lam*norm(x,1);
end