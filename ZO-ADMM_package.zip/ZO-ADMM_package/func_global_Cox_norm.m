function y = func_global_Cox_norm( x, A, delta, R, lam, norm_feature )
    N = size(A,2); %%% normalized data
    y = 0;
    for i = 1 : N,
            if delta(i) > 0
                y = y + (-delta(i)*A(:,i)'*x)/N;
                Ri = R{i};
                temp = 0;
                for j = 1:length(Ri)
                    jj = Ri(j);
                    temp = temp + exp( A(:,jj)'*x );
                end
                y = y + delta(i)*log(temp)/N;
            end
    end
    y = y + lam*sum((1./norm_feature).*abs(x)); 
end