function [f , grad]= func_loc_n_Cox(A, delta, R, i, x)

    
    f =  (-delta(i)*A(:,i)'*x);
    temp = 0; temp2 = 0;
    Ri = R{i};
    for j = 1:length(Ri)
            jj = Ri(j);
            temp = temp + exp( A(:,jj)'*x );
            temp2 = temp2 + A(:,jj)*exp( A(:,jj)'*x );
    end
     f = f + delta(i)*log(temp+1e-8);
     
     grad = delta(i)*( -A(:,i) + temp2/temp );
     
    
end