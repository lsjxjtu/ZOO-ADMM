%%%% Sijia Liu
%%%% Sparse Cox regression based on gene expression data
clc; clear all; close all;
load train_data_cox; %%% training data
load test_data_cox;  %%% testing data

delta_censoring = delta_censoring_train; %%% censoring indicator
daysurv = daysurv_train; %%% censoring time
A_allT = data_rna_train; %% d (number of genes) \times N (data samples)
d = size(A_allT,1); 
N = size(A_allT,2);
A_allT_ori = A_allT;
norm_feature = sqrt(sum(A_allT.*A_allT,2)); %%% each feature 
A_allT = A_allT./(norm_feature*ones(1,N));  %%% normalized to same scale for each gene
%%% compute Risk set 
Rist_set = [];
for i = 1:N
    Rist_set{i} = find(daysurv>=daysurv(i));
end

%%% test 
A_allT_test = data_rna_test; A_allT_ori_test = A_allT_test;
norm_feature_test = sqrt(sum(A_allT_test.*A_allT_test,2));
A_allT_test = A_allT_test./(norm_feature*ones(1, size(A_allT_test,2)));
%delta_censoring_test
%daysurv_test
Rist_set_test = [];
for i = 1:size(A_allT_test,2)
    Rist_set_test{i} = find(daysurv_test>=daysurv_test(i));
end

para_sparse_vec = 10; %logspace(-1,1,5); %% sparsity promoting parameter

for i = 1:length(para_sparse_vec)
     para_sparse = para_sparse_vec(i);
     %%%% OADMM/ZOADMM
    options.A = eye(d);
    options.B = -eye(d);
    options.c = zeros(d,1);
    options.rho = 0.1;
    if i == 1
        options.x0 = ones(d,1)*0.1;
    else
        options.x0 = x_ave_track_OADMM(:,end); %%% y
    end
    options.lam0 = zeros(d,1);
    options.y0 = inv(-options.B)*( options.A * options.x0 - options.c );
    
    options.a = 2; %%% Gt = aI - \eta_t*rho A'*A
    options.eta_const = 1; %%% step size for Bregman divergence
    options.grad_est_const = 1; %%% step size of directional derivative
    
    options.IterMax = 1e4; %%% max. iteration
    options.data1 = A_allT;  %%% online data
    options.data2 = delta_censoring;  %%% online data
    options.data3 = Rist_set;  %%% online data
    options.norm_feature = norm_feature;
    options.A_allT_ori = A_allT_ori;
    options.sparse_para = para_sparse;
            
    while 1
        if min(  eig( options.a*eye(d) - (options.eta_const)*options.rho *options.A.'*options.A ) ) < 1
            options.a = options.a*1.1;
        else
            break;
        end
    end
    
    %%% online ADMM
    options.grad_free = 0; %%% 0 non-zero order
    options.eps = 1e-6;  %%% stopping rule
    options.L_sub_batch_outter = 70;  options.L_sub_batch_inner = 1; %%% sub-batch strategy
    %%% call algorithm
    [x_ave_track_OADMM,y_ave_track_OADMM,eps_track_OADMM_tmp, obj_track_OADMM_tmp] = ZOADMM_Cox(options);
    eps_track_OADMM(:,i) = eps_track_OADMM_tmp;
    obj_track_OADMM(:,i) = obj_track_OADMM_tmp;
    xsol_track_OADMM(:,i) = x_ave_track_OADMM(:,end); %%% normalized weight
    xsol_norm_track_OADMM(i) =  sum((1./norm_feature).*abs(xsol_track_OADMM(:,i))); %norm(xsol_track_OADMM(:,i),1);
    plike_offline_track_OADMM(i) = func_global_Cox_norm( xsol_track_OADMM(:,i), A_allT, delta_censoring, Rist_set, 0 ,norm_feature); %%% (1/N) negative log partial likelihood
    disp(sprintf('O-ADMM with gamma = %3.4f, x_norm = %4.5f, plike = %4.5f',...
              para_sparse, xsol_norm_track_OADMM(i), plike_offline_track_OADMM(i)   )); 
            
    %%% OZADMM
    options.grad_free = 1; options.eps = 1e-6; 
    options.L_sub_batch_outter = 1;  options.L_sub_batch_inner = 70;
    [x_ave_track_ZOADMM,y_ave_track_ZOADMM,eps_track_ZOADMM_tmp, obj_track_ZOADMM_tmp] = ZOADMM_Cox(options);
    eps_track_ZOADMM(:,i) = eps_track_ZOADMM_tmp;
    obj_track_ZOADMM(:,i) = obj_track_ZOADMM_tmp;
    xsol_track_ZOADMM(:,i) =  x_ave_track_ZOADMM(:,end);
    xsol_norm_track_ZOADMM(i) = sum((1./norm_feature).*abs(xsol_track_ZOADMM(:,i)));%norm(xsol_track_ZOADMM(:,i),1);
    plike_offline_track_ZOADMM(i) = func_global_Cox_norm( xsol_track_ZOADMM(:,i), A_allT, delta_censoring, Rist_set, 0 ,norm_feature);
    disp(sprintf('ZO-ADMM with gamma = %3.4f, x_norm = %4.5f, plike = %4.5f',...
              para_sparse, xsol_norm_track_ZOADMM(i), plike_offline_track_ZOADMM(i)   )); 
          
end

%%% Check convergence
figure;
semilogx(eps_track_ZOADMM(:,1),'-b'); 
hold on;
semilogx(eps_track_OADMM(:,1),'--g'); 
xlabel('Iteration');
ylabel('Update error');
legend('ZOOADMM','OADMM');

figure;
semilogx(obj_track_ZOADMM(:,1),'-b'); 
hold on;
semilogx(obj_track_OADMM(:,1),'--g'); 
xlabel('Iteration');
ylabel('Objective value');
legend('ZOOADMM','OADMM');
